# Skating Bot Adventure

Skating Bot Adventure is a fun and educational game for 7 to 9-year-old girls. Control a cute little robot on ice skates as it navigates through a winter wonderland, avoiding obstacles and performing acrobatics!

## Features

- Winter wonderland theme with dynamic obstacles
- Acrobatic jumps and spins
- Multiple levels with increasing difficulty
- Educational elements integrated into gameplay
- Cross-platform compatibility (Mac and tablets)
- Engaging sound effects and background music

## Installation

1. Clone this repository:
   ```
   git clone https://github.com/your-username/skating-bot-adventure.git
   cd skating-bot-adventure
   ```

2. Create a virtual environment (optional but recommended):
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
   ```

3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Running the Game

To start the game, run:
```
python src/main.py
```

## How to Play

- Tap or click to make the robot jump
- Swipe or move the mouse left/right to move the robot
- Perform acrobatics by jumping on slopes
- Answer educational questions to earn bonus points
- Collect all items and reach the end of each level to progress

## Development

### Project Structure

```
skating_bot_adventure/
├── src/
│   ├── main.py
│   ├── game/
│   │   ├── game.py
│   │   ├── robot.py
│   │   ├── obstacles.py
│   │   └── levels.py
│   ├── utils/
│   │   ├── constants.py
│   │   ├── assets.py
│   │   ├── audio.py
│   │   └── education.py
│   └── assets/
│       ├── images/
│       └── sounds/
├── tests/
│   ├── test_robot.py
│   └── test_obstacles.py
├── docs/
│   └── developer_guide.md
├── README.md
└── requirements.txt
```

### Running Tests

To run the unit tests, execute:
```
python -m unittest discover tests
```

### Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

For more detailed information on contributing, please see the [Developer Guide](docs/developer_guide.md).

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Thanks to all contributors who have helped shape Skating Bot Adventure
- Special thanks to the Kivy community for their excellent cross-platform framework