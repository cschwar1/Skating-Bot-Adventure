from kivy.graphics import Color, Rectangle
from kivy.core.text import Label as CoreLabel
from utils.constants import WIDTH, HEIGHT, FPS, WHITE, BLACK, BLUE
from utils.assets import draw_background, draw_menu_background, draw_button
from utils.education import education_manager
from utils.audio import audio_manager
from game.robot import Robot
from game.obstacles import Obstacle, Slope
from game.levels import create_levels
from game.tutorial import tutorial

class Game:
    def __init__(self):
        self.robot = Robot(50, HEIGHT - 100)
        self.levels = create_levels()
        self.current_level = 0
        self.game_state = "MENU"
        self.educational_challenge = None
        self.show_fun_fact = False
        self.fun_fact = ""
        self.font_size = 24
        self.large_font_size = 36

    def handle_touch(self, x, y):
        if self.game_state == "MENU":
            if 300 < x < 500 and 250 < y < 300:
                self.game_state = "LEVEL_SELECT"
            elif 300 < x < 500 and 350 < y < 400:
                self.game_state = "TUTORIAL"
        elif self.game_state == "TUTORIAL":
            tutorial.next_step()
            if tutorial.current_step == 0:
                self.game_state = "MENU"
        elif self.game_state == "LEVEL_SELECT":
            level = self.check_level_selection(x, y)
            if level is not None:
                self.current_level = level
                self.game_state = "PLAYING"
                self.reset_game()
        elif self.game_state == "PLAYING":
            if self.educational_challenge:
                self.handle_educational_input(x, y)
            elif self.show_fun_fact:
                self.show_fun_fact = False
                self.next_level()
            else:
                self.robot.jump()
        elif self.game_state == "GAME_OVER":
            if 300 < x < 500 and 300 < y < 350:
                self.game_state = "LEVEL_SELECT"

    # ... (rest of the methods remain the same)

    def draw(self, canvas):
        if self.game_state == "MENU":
            self.draw_menu(canvas)
        elif self.game_state == "TUTORIAL":
            draw_menu_background(canvas)
            tutorial.draw(canvas)
        elif self.game_state == "LEVEL_SELECT":
            self.draw_level_select(canvas)
        elif self.game_state == "PLAYING":
            draw_background(canvas)
            self.levels[self.current_level].draw(canvas)
            self.robot.draw(canvas)
            self.draw_hud(canvas)
            
            if self.educational_challenge:
                self.draw_educational_challenge(canvas)
            elif self.show_fun_fact:
                self.draw_fun_fact(canvas)
        elif self.game_state == "GAME_OVER":
            self.draw_game_over(canvas)

    # ... (rest of the methods remain the same)